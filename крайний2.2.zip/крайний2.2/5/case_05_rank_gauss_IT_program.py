"""
Дополнительная программа к кейсу 5 «Диагностика избыточных метрик и устойчивости расчёта в IT-системе».
Тема: ранг матрицы, метод Гаусса, расширенная матрица, теорема Кронекера--Капелли.

Что делает студент:
1. Запускает файл после установки NumPy.
2. Выполняет блоки TASK 1--TASK 8.
3. Сравнивает результаты с рабочей тетрадью.
4. Сдаёт заполненный .py файл вместе с PDF рабочей тетради.
"""

import numpy as np

np.set_printoptions(precision=4, suppress=True)

A = np.array([
    [1, 3, 4],
    [3, 2, 1],
    [2, -1, -3],
], dtype=float)

B = np.array([
    [2, -1, -4, 7],
    [5, -3, -9, 17],
    [-3, 0, 9, -12],
    [1, 1, -5, 5],
], dtype=float)

b = np.array([7, 19, -6, -1], dtype=float)

C = np.array([
    [2, 1, -1],
    [1, -3, 2],
    [3, -1, 1],
], dtype=float)

c = np.array([8, -11, 3], dtype=float)

D = np.array([
    [1, 2, 1],
    [2, 4, 2],
    [1, -1, 0],
], dtype=float)

d = np.array([3, 7, 0], dtype=float)


def print_matrix(name: str, matrix: np.ndarray) -> None:
    print(f"\n{name} shape={matrix.shape}")
    print(matrix)


def augmented(matrix: np.ndarray, vector: np.ndarray) -> np.ndarray:
    """Строит расширенную матрицу (A | b)."""
    return np.column_stack([matrix, vector])


def rref(matrix: np.ndarray, tol: float = 1e-10) -> np.ndarray:
    """Возвращает сокращённый ступенчатый вид матрицы методом Гаусса--Жордана."""
    m = matrix.astype(float).copy()
    rows, cols = m.shape
    pivot_row = 0
    for col in range(cols):
        if pivot_row >= rows:
            break
        pivot = pivot_row + np.argmax(np.abs(m[pivot_row:, col]))
        if abs(m[pivot, col]) < tol:
            continue
        if pivot != pivot_row:
            m[[pivot_row, pivot]] = m[[pivot, pivot_row]]
        m[pivot_row] = m[pivot_row] / m[pivot_row, col]
        for r in range(rows):
            if r != pivot_row:
                m[r] = m[r] - m[r, col] * m[pivot_row]
        pivot_row += 1
    m[np.abs(m) < tol] = 0.0
    return m


def classify_system(matrix: np.ndarray, vector: np.ndarray) -> str:
    """Классифицирует систему по теореме Кронекера--Капелли."""
    rank_a = np.linalg.matrix_rank(matrix)
    rank_aug = np.linalg.matrix_rank(augmented(matrix, vector))
    n = matrix.shape[1]
    if rank_a != rank_aug:
        return "система несовместна"
    if rank_a == n:
        return "система совместна и имеет единственное решение"
    return "система совместна и имеет бесконечно много решений"


# ============================================================
# TASK 1. Ранг матрицы метрик A
# ============================================================
print("TASK 1. Ранг матрицы A")
print_matrix("A", A)
print_matrix("rref(A)", rref(A))
rank_A = np.linalg.matrix_rank(A)
print("rank(A) =", rank_A)

# TODO: в рабочей тетради покажите ручное приведение A к ступенчатому виду.


# ============================================================
# TASK 2. Расширенная матрица основного сценария
# ============================================================
print("\nTASK 2. Расширенная матрица (B | b)")
Bb = augmented(B, b)
print_matrix("B", B)
print("b =", b)
print_matrix("(B | b)", Bb)
print_matrix("rref(B | b)", rref(Bb))

# TODO: перенесите расширенную матрицу и ключевые преобразования в тетрадь.


# ============================================================
# TASK 3. Теорема Кронекера--Капелли для основного сценария
# ============================================================
print("\nTASK 3. Совместность основного сценария")
rank_B = np.linalg.matrix_rank(B)
rank_Bb = np.linalg.matrix_rank(Bb)
print("rank(B) =", rank_B)
print("rank(B | b) =", rank_Bb)
print("Количество неизвестных n =", B.shape[1])
print("Вывод:", classify_system(B, b))
print("Число свободных параметров =", B.shape[1] - rank_B)

# TODO: запишите вывод по теореме Кронекера--Капелли.


# ============================================================
# TASK 4. Общее решение методом Гаусса
# ============================================================
print("\nTASK 4. Общее решение системы Bx=b")
print("Из rref(B | b):")
print("x1 - 3*x3 + 4*x4 = 2")
print("x2 - 2*x3 + 1*x4 = -3")
print("Пусть x3=t, x4=s")
print("x(t,s) = t*[3, 2, 1, 0] + s*[-4, -1, 0, 1] + [2, -3, 0, 0]")
for t, s in [(0, 0), (1, 0), (0, 1), (2, -1)]:
    x = np.array([3*t - 4*s + 2, 2*t - s - 3, t, s], dtype=float)
    print(f"t={t}, s={s}: x={x}, B@x={B @ x}")

# TODO: проверьте одно выбранное значение параметров вручную.


# ============================================================
# TASK 5. Сценарий с единственным решением
# ============================================================
print("\nTASK 5. Система Cx=c")
Cc = augmented(C, c)
print_matrix("C", C)
print("c =", c)
print_matrix("rref(C | c)", rref(Cc))
print("rank(C) =", np.linalg.matrix_rank(C))
print("rank(C | c) =", np.linalg.matrix_rank(Cc))
print("Вывод:", classify_system(C, c))
x_unique = np.linalg.solve(C, c)
print("Решение x =", x_unique)
print("Проверка C@x =", C @ x_unique)

# TODO: сравните решение с ручным методом Гаусса.


# ============================================================
# TASK 6. Сценарий с противоречивыми данными
# ============================================================
print("\nTASK 6. Система Dx=d")
Dd = augmented(D, d)
print_matrix("D", D)
print("d =", d)
print_matrix("rref(D | d)", rref(Dd))
print("rank(D) =", np.linalg.matrix_rank(D))
print("rank(D | d) =", np.linalg.matrix_rank(Dd))
print("Вывод:", classify_system(D, d))

# TODO: объясните, почему строки телеметрии противоречат друг другу.


# ============================================================
# TASK 7. Сравнение рангов
# ============================================================
print("\nTASK 7. Таблица рангов")
objects = [
    ("A", A),
    ("B", B),
    ("(B | b)", Bb),
    ("C", C),
    ("(C | c)", Cc),
    ("D", D),
    ("(D | d)", Dd),
]
for name, matrix in objects:
    print(f"{name:8s} rank = {np.linalg.matrix_rank(matrix)}")

# TODO: заполните таблицу в рабочей тетради.


# ============================================================
# TASK 8. Итоговые факты для инженерного заключения
# ============================================================
print("\nTASK 8. Итоговые факты")
print(f"1. rank(A) = {rank_A}: в матрице A только две независимые строки из трёх.")
print(f"2. Для Bx=b: rank(B) = {rank_B}, rank(B|b) = {rank_Bb}, поэтому система совместна.")
print("3. Так как неизвестных 4, а ранг равен 2, остаются два свободных параметра.")
print("4. Система Cx=c имеет единственное решение, потому что общий ранг равен числу неизвестных.")
print("5. Система Dx=d несовместна: ранги D и (D|d) различаются.")
print("6. Итоговую рекомендацию сформулируйте в рабочей тетради.")
