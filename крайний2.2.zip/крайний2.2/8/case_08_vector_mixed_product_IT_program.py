"""
Дополнительная программа к кейсу 8 «Геометрический модуль проверки 3D-сцены».
Тема: векторное произведение, смешанное произведение, площадь, объём, компланарность.

Что делает студент:
1. Запускает файл после установки NumPy.
2. Выполняет блоки TASK 1--TASK 8.
3. Сравнивает результаты с рабочей тетрадью.
4. Сдаёт заполненный .py файл вместе с PDF рабочей тетради.
"""

import math
import numpy as np

np.set_printoptions(precision=4, suppress=True)

A1 = np.array([1, 1, 1], dtype=float)
B1 = np.array([2, -3, 4], dtype=float)
C1 = np.array([4, 3, 2], dtype=float)

A2 = np.array([1, -1, 2], dtype=float)
B2 = np.array([5, -6, 2], dtype=float)
C2 = np.array([1, 3, -1], dtype=float)

O = np.array([-5, -4, 8], dtype=float)
A = np.array([2, 3, 1], dtype=float)
B = np.array([4, 1, -2], dtype=float)
C = np.array([6, 3, 7], dtype=float)

avec = np.array([-2, 1, 1], dtype=float)
bvec = np.array([1, -2, 3], dtype=float)
cvec = np.array([14, -13, 7], dtype=float)


def norm(v: np.ndarray) -> float:
    return float(np.linalg.norm(v))


def cross(u: np.ndarray, v: np.ndarray) -> np.ndarray:
    return np.cross(u, v)


def triple(u: np.ndarray, v: np.ndarray, w: np.ndarray) -> float:
    return float(np.dot(np.cross(u, v), w))


def triangle_area_by_points(P: np.ndarray, Q: np.ndarray, R: np.ndarray) -> float:
    return 0.5 * norm(cross(Q - P, R - P))


# ============================================================
# TASK 1. Площадь треугольного полигона
# ============================================================
print("TASK 1. Площадь треугольного полигона")
AB1 = B1 - A1
AC1 = C1 - A1
normal1 = cross(AB1, AC1)
area1 = 0.5 * norm(normal1)
print("A1B1 =", AB1)
print("A1C1 =", AC1)
print("[A1B1, A1C1] =", normal1)
print(f"S_triangle = {area1:.6f}")

# TODO: перенесите в рабочую тетрадь векторы, нормаль и площадь.


# ============================================================
# TASK 2. Высота в треугольнике
# ============================================================
print("\nTASK 2. Высота в треугольнике")
area2 = triangle_area_by_points(A2, B2, C2)
base_A2C2 = norm(C2 - A2)
height_B2 = 2 * area2 / base_A2C2
print(f"S_A2B2C2 = {area2:.6f}")
print(f"|A2C2| = {base_A2C2:.6f}")
print(f"h_B2 = {height_B2:.6f}")

# TODO: объясните, почему высота вычисляется как 2S / основание.


# ============================================================
# TASK 3. Площадь по линейным комбинациям
# ============================================================
print("\nTASK 3. Площадь по линейным комбинациям")
# [a - 2b, a + 3b] = 3[a,b] - 2[b,a] = 5[a,b]
base_cross_abs = 5 * 5 * math.sin(math.pi / 4)
combo_cross_abs = 5 * base_cross_abs
triangle_combo_area = 0.5 * combo_cross_abs
print(f"|[a,b]| = {base_cross_abs:.6f}")
print(f"|[a - 2b, a + 3b]| = {combo_cross_abs:.6f}")
print(f"S_triangle = {triangle_combo_area:.6f}")

# TODO: в рабочей тетради покажите преобразование векторного произведения.


# ============================================================
# TASK 4. Площадь параллелограмма
# ============================================================
print("\nTASK 4. Площадь параллелограмма")
# [a + 2b, 2a + b] = [a,b] + 4[b,a] = -3[a,b]
base_cross_abs2 = 1 * 1 * math.sin(math.pi / 3)
parallelogram_area = 3 * base_cross_abs2
print(f"|[a,b]| = {base_cross_abs2:.6f}")
print(f"S_parallelogram = {parallelogram_area:.6f}")

# TODO: сравните с ручным расчётом в рабочей тетради.


# ============================================================
# TASK 5. Объём пирамиды
# ============================================================
print("\nTASK 5. Объём пирамиды")
OA = A - O
OB = B - O
OC = C - O
mixed_OABC = triple(OA, OB, OC)
volume_pyramid = abs(mixed_OABC) / 6
print("OA =", OA)
print("OB =", OB)
print("OC =", OC)
print(f"(OA, OB, OC) = {mixed_OABC:.6f}")
print(f"V_pyramid = {volume_pyramid:.6f}")

# TODO: в рабочей тетради укажите, почему делим модуль смешанного произведения на 6.


# ============================================================
# TASK 6. Компланарность векторов
# ============================================================
print("\nTASK 6. Компланарность векторов")
tr_abc = triple(avec, bvec, cvec)
print(f"(a,b,c) = {tr_abc:.6f}")
print("Векторы компланарны?", "да" if abs(tr_abc) < 1e-9 else "нет")

# TODO: сформулируйте прикладной смысл компланарности.


# ============================================================
# TASK 7. Параметр lambda
# ============================================================
print("\nTASK 7. Параметр lambda")
q = np.array([5, -1, 2], dtype=float)
r = np.array([-1, 5, 4], dtype=float)

def det_for_lambda(lmbd: float) -> float:
    p = np.array([lmbd, 3, 1], dtype=float)
    return triple(p, q, r)

b0 = det_for_lambda(0)
b1 = det_for_lambda(1)
coef = b1 - b0
lambda_value = -b0 / coef
print(f"det(lambda) = {coef:.6f} * lambda + {b0:.6f}")
print(f"lambda = {lambda_value:.6f}")
print(f"Проверка det(lambda) = {det_for_lambda(lambda_value):.6f}")

# TODO: перенесите линейное уравнение по lambda в рабочую тетрадь.


# ============================================================
# TASK 8. Итоговые факты для инженерного заключения
# ============================================================
print("\nTASK 8. Итоговые факты")
print(f"1. Нормаль первого треугольника: {normal1}; площадь = {area1:.6f}.")
print(f"2. Высота из B2 к A2C2 равна {height_B2:.6f}.")
print(f"3. Объём пирамиды OABC равен {volume_pyramid:.6f}.")
print(f"4. Векторы a,b,c компланарны: {'да' if abs(tr_abc) < 1e-9 else 'нет'}.")
print(f"5. Компланарность параметрической тройки достигается при lambda = {lambda_value:.6f}.")
print("6. Итоговую рекомендацию сформулируйте в рабочей тетради.")
