"""
Дополнительная программа к кейсу 9 «Модуль навигации объектов на 2D-карте».
Тема: прямая на плоскости, расстояние от точки до прямой, угол между прямыми, проекция точки.

Что делает студент:
1. Запускает файл после установки NumPy.
2. Выполняет блоки TASK 1--TASK 8.
3. Сравнивает результаты с рабочей тетрадью.
4. Сдаёт заполненный .py файл вместе с PDF рабочей тетради.
"""

import math
import numpy as np

np.set_printoptions(precision=4, suppress=True)


def line_from_point_normal(point: np.ndarray, normal: np.ndarray) -> np.ndarray:
    """Возвращает коэффициенты A, B, C прямой Ax + By + C = 0."""
    A, B = normal
    C = -(A * point[0] + B * point[1])
    return np.array([A, B, C], dtype=float)


def line_from_two_points(P: np.ndarray, Q: np.ndarray) -> np.ndarray:
    """Прямая через две точки в виде Ax + By + C = 0."""
    x1, y1 = P
    x2, y2 = Q
    A = y1 - y2
    B = x2 - x1
    C = x1 * y2 - x2 * y1
    return np.array([A, B, C], dtype=float)


def normalize_line(line: np.ndarray) -> np.ndarray:
    """Нормировка для удобного вывода."""
    line = line.astype(float)
    if abs(line[0]) > 1e-9:
        line = line / line[0]
    elif abs(line[1]) > 1e-9:
        line = line / line[1]
    return line


def point_line_distance(point: np.ndarray, line: np.ndarray) -> float:
    A, B, C = line
    x0, y0 = point
    return abs(A * x0 + B * y0 + C) / math.sqrt(A * A + B * B)


def angle_between_lines(line1: np.ndarray, line2: np.ndarray) -> float:
    A1, B1, _ = line1
    A2, B2, _ = line2
    cos_a = abs(A1 * A2 + B1 * B2) / (math.hypot(A1, B1) * math.hypot(A2, B2))
    cos_a = min(1.0, max(-1.0, cos_a))
    return math.acos(cos_a)


def projection_point_to_line(P: np.ndarray, A: np.ndarray, B: np.ndarray) -> np.ndarray:
    d = B - A
    t = np.dot(P - A, d) / np.dot(d, d)
    return A + t * d


# ============================================================
# TASK 1. Параллель и перпендикуляр к маршруту
# ============================================================
print("TASK 1. Параллель и перпендикуляр к маршруту")
M = np.array([1, 1], dtype=float)
base_line = np.array([2, -3, -1], dtype=float)
parallel_line = line_from_point_normal(M, base_line[:2])
# Направляющий вектор исходной прямой можно взять (3, 2). Он станет нормалью перпендикуляра.
perpendicular_line = line_from_point_normal(M, np.array([3, 2], dtype=float))
print("Параллельная прямая:", parallel_line, "то есть 2x - 3y + 1 = 0")
print("Перпендикулярная прямая:", perpendicular_line, "то есть 3x + 2y - 5 = 0")

# TODO: проверьте, что точка M лежит на обеих прямых.


# ============================================================
# TASK 2. Прямая по точке и углу направления
# ============================================================
print("\nTASK 2. Прямая по точке и углу направления")
A_point = np.array([-3, 5], dtype=float)
alpha = 3 * math.pi / 4
k = math.tan(alpha)
# y - 5 = -1(x + 3) => x + y - 2 = 0
angle_line = np.array([1, 1, -2], dtype=float)
print(f"k = tan(3pi/4) = {k:.6f}")
print("Прямая:", angle_line, "то есть x + y - 2 = 0")

# TODO: перенесите вычисление углового коэффициента в рабочую тетрадь.


# ============================================================
# TASK 3. Проверка нахождения объектов на одной линии
# ============================================================
print("\nTASK 3. Проверка нахождения объектов на одной линии")
A3 = np.array([2, 1], dtype=float)
B3 = np.array([-3, 3], dtype=float)
C3 = np.array([7, -1], dtype=float)
line_ABC = line_from_two_points(A3, B3)
print("AB =", B3 - A3)
print("AC =", C3 - A3)
print("Уравнение прямой через A и B:", line_ABC, "то есть 2x + 5y - 9 = 0")
print("Значение для точки C:", np.dot(line_ABC[:2], C3) + line_ABC[2])

# TODO: объясните, почему нулевое значение означает принадлежность точки прямой.


# ============================================================
# TASK 4. Служебные линии треугольной зоны
# ============================================================
print("\nTASK 4. Служебные линии треугольной зоны")
A4 = np.array([2, -5], dtype=float)
B4 = np.array([1, -2], dtype=float)
C4 = np.array([4, 7], dtype=float)
mid_AC = (A4 + C4) / 2
median_B = line_from_two_points(B4, mid_AC)
# Высота из B перпендикулярна AC; нормаль высоты параллельна AC.
height_B = line_from_point_normal(B4, C4 - A4)
# В этом треугольнике внутренняя биссектриса из B получается горизонтальной.
bisector_B = np.array([0, 1, 2], dtype=float)  # y + 2 = 0
print("M_AC =", mid_AC)
print("Медиана из B:", median_B, "то есть 3x - 2y - 7 = 0")
print("Высота из B:", height_B, "то есть x + 6y + 11 = 0")
print("Биссектриса из B:", bisector_B, "то есть y + 2 = 0")

# TODO: в рабочей тетради покажите построение каждой служебной линии.


# ============================================================
# TASK 5. Ширина коридора между параллельными линиями
# ============================================================
print("\nTASK 5. Ширина коридора между параллельными линиями")
line5_1 = np.array([2, 3, -1], dtype=float)
line5_2_original = np.array([-4, -6, -3], dtype=float)
line5_2 = line5_2_original / -2  # 2x + 3y + 1.5 = 0
# Возьмём точку на первой прямой: x=0, y=1/3.
point_on_line5_1 = np.array([0, 1 / 3], dtype=float)
distance_parallel = point_line_distance(point_on_line5_1, line5_2)
print("Вторая прямая после приведения:", line5_2)
print(f"d = {distance_parallel:.6f} = 5/(2*sqrt(13))")

# TODO: объясните, почему расстояние между параллельными прямыми можно считать через любую точку первой прямой.


# ============================================================
# TASK 6. Угол пересечения маршрутов
# ============================================================
print("\nTASK 6. Угол пересечения маршрутов")
line6_1 = np.array([1, 3, -2], dtype=float)
line6_2 = np.array([2, 1, 1], dtype=float)
angle = angle_between_lines(line6_1, line6_2)
print(f"cos(alpha) = {math.cos(angle):.6f}")
print(f"alpha = {angle:.6f} rad = {math.degrees(angle):.6f} degrees")

# TODO: перенесите вычисление угла в рабочую тетрадь.


# ============================================================
# TASK 7. Формы уравнения прямой
# ============================================================
print("\nTASK 7. Формы уравнения прямой")
A7 = np.array([0, 4], dtype=float)
B7 = np.array([-3, -5], dtype=float)
d7 = B7 - A7
line7 = line_from_two_points(A7, B7)
print("AB =", d7)
print("Каноническое: x/(-3) = (y - 4)/(-9)")
print("Общее:", line7, "то есть 3x - y + 4 = 0")
print("В отрезках: x/(-4/3) + y/4 = 1")

# TODO: найдите точки пересечения с осями и запишите уравнение в отрезках.


# ============================================================
# TASK 8. Ближайшая точка маршрута и итоговые факты
# ============================================================
print("\nTASK 8. Ближайшая точка маршрута")
P8 = np.array([-8, 12], dtype=float)
A8 = np.array([2, -3], dtype=float)
B8 = np.array([-5, 1], dtype=float)
H = projection_point_to_line(P8, A8, B8)
print("Направляющий вектор маршрута:", B8 - A8)
print("Проекция H =", H)
print("Проверка перпендикулярности PH и AB:", np.dot(P8 - H, B8 - A8))

print("\nИтоговые факты")
print("1. Параллель через M: 2x - 3y + 1 = 0.")
print("2. Перпендикуляр через M: 3x + 2y - 5 = 0.")
print("3. Точки A, B, C лежат на прямой 2x + 5y - 9 = 0.")
print(f"4. Расстояние между параллельными прямыми равно {distance_parallel:.6f}.")
print(f"5. Угол между маршрутами равен {math.degrees(angle):.6f} градусов.")
print(f"6. Проекция точки P на маршрут равна ({H[0]:.6f}, {H[1]:.6f}).")
print("7. Итоговую рекомендацию сформулируйте в рабочей тетради.")
