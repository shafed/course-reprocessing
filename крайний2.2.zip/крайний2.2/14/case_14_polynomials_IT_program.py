"""
Дополнительная программа к кейсу 14 «Многочлены в анализе характеристических моделей».
Тема: корни многочленов, кратность корня, разложение на множители.

Что делает студент:
1. Запускает файл после установки SymPy и NumPy.
2. Выполняет блоки TASK 1--TASK 8.
3. Сравнивает результаты с рабочей тетрадью.
4. Сдаёт заполненный .py файл вместе с PDF рабочей тетради.
"""

import cmath
import math
from collections import Counter

import numpy as np
import sympy as sp

sp.init_printing()
np.set_printoptions(precision=5, suppress=True)

z = sp.symbols("z")
i = sp.I

P1 = z**4 + 2*z**3 - z - 2
P2 = 3*z**4 - 7*z**3 - 6*z**2 + z - 3
P3 = 2*z**6 - 6*z**5 + 11*z**4 - 15*z**3 + 9*z**2 + z - 2
P4 = z**4 + 4*z**3 + 11*z**2 + 14*z + 10
P5 = z**5 + z**4 + z**3 - z**2 - z - 1


def print_header(title: str) -> None:
    print("\n" + "=" * 68)
    print(title)
    print("=" * 68)


def roots_by_formula_for_power(value: complex, degree: int) -> list[complex]:
    """Все корни уравнения x**degree = value."""
    r, phi = cmath.polar(value)
    return [r ** (1 / degree) * cmath.exp(1j * (phi + 2 * math.pi * k) / degree) for k in range(degree)]


def print_complex_list(name: str, values: list[complex], digits: int = 5) -> None:
    print(name)
    for index, value in enumerate(values):
        print(f"  {index}: {value.real:.{digits}f} {value.imag:+.{digits}f}i")


def exact_factor(poly: sp.Expr) -> None:
    print("Многочлен:", poly)
    print("Факторизация над рациональными/алгебраическими числами:")
    print(sp.factor(poly))
    print("Корни с кратностями:")
    print(sp.roots(poly, z))
    print("Численные корни:")
    for root in sp.nroots(poly):
        print(" ", sp.N(root, 8))


# ============================================================
# TASK 1. Уравнение z^2 = conjugate(z)
# ============================================================
print_header("TASK 1. Уравнение z^2 = conjugate(z)")
x, y = sp.symbols("x y", real=True)
expr = (x + i*y)**2 - (x - i*y)
system = [sp.Eq(sp.re(expr), 0), sp.Eq(sp.im(expr), 0)]
solutions_xy = sp.solve(system, (x, y), dict=True)
solutions_z = [sp.simplify(sol[x] + i*sol[y]) for sol in solutions_xy]
print("Система для x и y:", system)
print("Решения (x, y):", solutions_xy)
print("Решения z:", solutions_z)

# TODO: перенесите переход от z=x+iy к системе в рабочую тетрадь.


# ============================================================
# TASK 2. Уравнение z^4 + 1 - i = 0
# ============================================================
print_header("TASK 2. Уравнение z^4 + 1 - i = 0")
value = -1 + 1j  # z^4 = -1 + i
roots_task2 = roots_by_formula_for_power(value, 4)
print_complex_list("Корни уравнения:", roots_task2)
print("Проверка z**4 + 1 - i:")
for root in roots_task2:
    print(f"  {root**4 + 1 - 1j:.3e}")

# TODO: запишите показательную форму числа -1+i и формулу корней.


# ============================================================
# TASK 3. Уравнение z^6 + (2-2i)z^3 - 2i = 0
# ============================================================
print_header("TASK 3. Уравнение шестой степени через замену w=z^3")
w = sp.symbols("w")
quadratic_w = w**2 + (2 - 2*i)*w - 2*i
w_roots = sp.solve(sp.Eq(quadratic_w, 0), w)
print("Квадратное уравнение по w:", quadratic_w)
print("Корни w:", w_roots)
all_z_roots = []
for w_root in w_roots:
    complex_w = complex(sp.N(w_root))
    roots_for_w = roots_by_formula_for_power(complex_w, 3)
    print_complex_list(f"Корни z для w={w_root}:", roots_for_w)
    all_z_roots.extend(roots_for_w)
print("Всего корней z:", len(all_z_roots))

# TODO: в рабочей тетради покажите замену w=z^3 и восстановление всех z.


# ============================================================
# TASK 4. Многочлен P1
# ============================================================
print_header("TASK 4. P1(z)=z^4+2z^3-z-2")
exact_factor(P1)
print("Разложение на действительные множители удобно записать как:")
print(sp.factor(P1, extension=i))

# TODO: проверьте рациональные корни и запишите кратности.


# ============================================================
# TASK 5. Многочлен P2
# ============================================================
print_header("TASK 5. P2(z)=3z^4-7z^3-6z^2+z-3")
exact_factor(P2)
print("Проверка значений P2(root) для численных корней:")
for root in sp.nroots(P2):
    print(" ", sp.N(P2.subs(z, root), 8))

# TODO: сравните точное/численное разложение с ручным решением.


# ============================================================
# TASK 6. Кратность корня z=1 для P3
# ============================================================
print_header("TASK 6. Кратность корня z=1 для P3")
print("P3(1) =", sp.simplify(P3.subs(z, 1)))
for order in range(1, 7):
    derivative_value = sp.diff(P3, z, order).subs(z, 1)
    print(f"P3^{order}(1) = {sp.simplify(derivative_value)}")
print("Факторизация P3:", sp.factor(P3))
print("Кратность корня 1:", sp.roots(P3, z).get(sp.Integer(1), 0))

# TODO: объясните, как производные помогают определить кратность корня.


# ============================================================
# TASK 7. P4 с известным корнем -1+i
# ============================================================
print_header("TASK 7. P4(z), известен корень -1+i")
known_root_4 = -1 + i
conjugate_root_4 = sp.conjugate(known_root_4)
quadratic_factor_4 = sp.expand((z - known_root_4) * (z - conjugate_root_4))
quotient_4, remainder_4 = sp.div(P4, quadratic_factor_4, domain=sp.QQ)
print("Известный корень:", known_root_4)
print("Сопряжённый корень:", conjugate_root_4)
print("Квадратичный множитель:", quadratic_factor_4)
print("Частное:", quotient_4)
print("Остаток:", remainder_4)
print("Факторизация:", sp.factor(P4))
print("Корни:", sp.roots(P4, z))

# TODO: покажите деление P4 на квадратичный множитель в рабочей тетради.


# ============================================================
# TASK 8. P5 с известным корнем -1/2 + sqrt(3)/2 i
# ============================================================
print_header("TASK 8. P5(z), известен корень -1/2 + sqrt(3)/2 i")
known_root_5 = -sp.Rational(1, 2) + sp.sqrt(3) * i / 2
conjugate_root_5 = sp.conjugate(known_root_5)
quadratic_factor_5 = sp.expand((z - known_root_5) * (z - conjugate_root_5))
quotient_5, remainder_5 = sp.div(P5, quadratic_factor_5, domain=sp.QQ.algebraic_field(sp.sqrt(3)))
print("Известный корень:", known_root_5)
print("Сопряжённый корень:", conjugate_root_5)
print("Квадратичный множитель:", sp.simplify(quadratic_factor_5))
print("Частное:", quotient_5)
print("Остаток:", remainder_5)
print("Факторизация:", sp.factor(P5))
print("Корни с кратностями:", sp.roots(P5, z))
print("Численные корни:")
for root in sp.nroots(P5):
    print(" ", sp.N(root, 8))

# TODO: в итоговом заключении объясните, какие корни являются комплексными.
