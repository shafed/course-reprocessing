"""
Дополнительная программа к кейсу 4 «Система уравнений в распределении нагрузки IT-сервиса».
Тема: системы линейных уравнений, матричная форма AX=b, метод обратной матрицы, метод Крамера.

Что делает студент:
1. Запускает файл после установки NumPy.
2. Выполняет блоки TASK 1--TASK 8.
3. Сравнивает результаты с рабочей тетрадью.
4. Сдаёт заполненный .py файл вместе с PDF рабочей тетради.
"""

import numpy as np

np.set_printoptions(precision=4, suppress=True)

A2 = np.array([
    [1, 1],
    [3, -1],
], dtype=float)

b2 = np.array([3, 5], dtype=float)

A3 = np.array([
    [3, 2, 1],
    [2, -1, 1],
    [1, 5, 0],
], dtype=float)

b3 = np.array([5, 6, -3], dtype=float)

A4 = np.array([
    [2, 2, -1, 1],
    [4, 3, -1, 2],
    [8, 5, -3, 4],
    [3, 3, -2, 2],
], dtype=float)

b4 = np.array([4, 6, 12, 6], dtype=float)

M = np.array([
    [5, 3, 1],
    [1, -3, -2],
    [-5, 2, 1],
], dtype=float)

N = np.array([
    [-8, 3, 0],
    [-5, 9, 0],
    [-2, 15, 0],
], dtype=float)

As = np.array([
    [1, 1],
    [2, 2],
], dtype=float)

bs = np.array([2, 4], dtype=float)


def print_matrix(name: str, matrix: np.ndarray) -> None:
    print(f"\n{name} shape={matrix.shape}")
    print(matrix)


def det_value(matrix: np.ndarray) -> float:
    """Возвращает определитель матрицы."""
    return float(np.linalg.det(matrix))


def replace_column(matrix: np.ndarray, col: int, vector: np.ndarray) -> np.ndarray:
    """Заменяет столбец col на vector. Индексы Python начинаются с 0."""
    result = matrix.copy()
    result[:, col] = vector
    return result


def solve_with_cramer(matrix: np.ndarray, vector: np.ndarray) -> np.ndarray:
    """Решает систему методом Крамера для невырожденной квадратной матрицы."""
    delta = det_value(matrix)
    if abs(delta) < 1e-9:
        raise ValueError("Метод Крамера неприменим: det(A) = 0")
    values = []
    for col in range(matrix.shape[1]):
        delta_i = det_value(replace_column(matrix, col, vector))
        values.append(delta_i / delta)
    return np.array(values)


# ============================================================
# TASK 1. Исходные системы и матричная форма
# ============================================================
print("TASK 1. Исходные данные")
print_matrix("A2", A2)
print("b2 =", b2)
print_matrix("A3", A3)
print("b3 =", b3)
print_matrix("A4", A4)
print("b4 =", b4)
print_matrix("M", M)
print_matrix("N", N)

# TODO: в рабочей тетради запишите системы в виде AX=b.


# ============================================================
# TASK 2. Система второго порядка двумя способами
# ============================================================
print("\nTASK 2. Решение системы второго порядка")
det_A2 = det_value(A2)
A2_inv = np.linalg.inv(A2)
x2_inverse = A2_inv @ b2
x2_cramer = solve_with_cramer(A2, b2)
print(f"det(A2) = {det_A2:.6f}")
print_matrix("A2^{-1}", A2_inv)
print("x через A^{-1}b =", x2_inverse)
print("x через Крамера =", x2_cramer)
print("Проверка A2 @ x =", A2 @ x2_inverse)

# TODO: сравните оба способа с ручным решением.


# ============================================================
# TASK 3. Система третьего порядка
# ============================================================
print("\nTASK 3. Решение системы третьего порядка")
det_A3 = det_value(A3)
x3 = np.linalg.solve(A3, b3)
print(f"det(A3) = {det_A3:.6f}")
print("x =", x3)
print("Проверка A3 @ x =", A3 @ x3)

# TODO: перенесите решение и проверку в рабочую тетрадь.


# ============================================================
# TASK 4. Координата x3 по формулам Крамера
# ============================================================
print("\nTASK 4. x3 по формулам Крамера")
delta = det_value(A4)
A4_delta3 = replace_column(A4, 2, b4)
delta3 = det_value(A4_delta3)
x3_cramer = delta3 / delta
x4_full = np.linalg.solve(A4, b4)
print(f"Delta = det(A4) = {delta:.6f}")
print_matrix("A4 с заменённым третьим столбцом", A4_delta3)
print(f"Delta_3 = {delta3:.6f}")
print(f"x_3 = Delta_3 / Delta = {x3_cramer:.6f}")
print("Полное решение для проверки =", x4_full)

# TODO: в тетради покажите именно замену третьего столбца.


# ============================================================
# TASK 5. Матричное уравнение XM=N
# ============================================================
print("\nTASK 5. Матричное уравнение XM=N")
det_M = det_value(M)
M_inv = np.linalg.inv(M)
X = N @ M_inv
print(f"det(M) = {det_M:.6f}")
print_matrix("M^{-1}", M_inv)
print_matrix("X = N @ M^{-1}", X)
print_matrix("Проверка X @ M", X @ M)

# TODO: сравните X @ M с исходной матрицей N.


# ============================================================
# TASK 6. Совместность системы с зависимыми уравнениями
# ============================================================
print("\nTASK 6. Совместность системы")
augmented = np.column_stack([As, bs])
rank_A = np.linalg.matrix_rank(As)
rank_aug = np.linalg.matrix_rank(augmented)
print_matrix("As", As)
print("bs =", bs)
print_matrix("(As | bs)", augmented)
print("rank(As) =", rank_A)
print("rank(As | bs) =", rank_aug)
print("Количество неизвестных n =", As.shape[1])
if rank_A == rank_aug == As.shape[1]:
    print("Вывод: решение единственное.")
elif rank_A == rank_aug < As.shape[1]:
    print("Вывод: решений бесконечно много.")
else:
    print("Вывод: система несовместна.")

# TODO: объясните прикладной смысл зависимых уравнений.


# ============================================================
# TASK 7. Сравнение методов
# ============================================================
print("\nTASK 7. Сравнение методов")
print("Метод обратной матрицы удобен для понимания структуры решения, но не всегда оптимален численно.")
print("Метод Крамера удобен для малых систем и отдельной координаты, например x3.")
print("np.linalg.solve обычно предпочтителен для инженерных расчётов.")
print(f"cond(A2) = {np.linalg.cond(A2):.6f}")
print(f"cond(A3) = {np.linalg.cond(A3):.6f}")
print(f"cond(A4) = {np.linalg.cond(A4):.6f}")

# TODO: заполните таблицу сравнения методов в рабочей тетради.


# ============================================================
# TASK 8. Итоговые факты для инженерного заключения
# ============================================================
print("\nTASK 8. Итоговые факты")
print(f"1. Система второго порядка имеет решение {x2_inverse}.")
print(f"2. det(A3) = {det_A3:.0f}, поэтому расширенная система имеет единственное решение {x3}.")
print(f"3. Для системы четвёртого порядка x_3 = {x3_cramer:.0f}.")
print("4. Матричное уравнение XM=N решено через X=N M^{-1}; проверка X @ M совпадает с N.")
print("5. Система с зависимыми уравнениями имеет бесконечно много решений.")
print("6. Итоговую рекомендацию сформулируйте в рабочей тетради.")
