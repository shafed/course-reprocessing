"""
Дополнительная программа к кейсу 11 «Кривые второго порядка в аналитическом модуле зон покрытия и траекторий».
Тема: эллипс, гипербола, парабола, канонический вид, фокусы, асимптоты, директриса.

Что делает студент:
1. Запускает файл после установки NumPy.
2. Выполняет блоки TASK 1--TASK 8.
3. Сравнивает результаты с рабочей тетрадью.
4. Сдаёт заполненный .py файл вместе с PDF рабочей тетради.
"""

import math
from dataclasses import dataclass


@dataclass
class Ellipse:
    center: tuple[float, float]
    a: float
    b: float
    major_axis: str

    def c(self) -> float:
        return math.sqrt(abs(self.a**2 - self.b**2))

    def foci(self) -> tuple[tuple[float, float], tuple[float, float]]:
        h, k = self.center
        c = self.c()
        if self.major_axis == "x":
            return (h - c, k), (h + c, k)
        return (h, k - c), (h, k + c)


@dataclass
class Hyperbola:
    center: tuple[float, float]
    a: float
    b: float
    transverse_axis: str

    def c(self) -> float:
        return math.sqrt(self.a**2 + self.b**2)

    def foci(self) -> tuple[tuple[float, float], tuple[float, float]]:
        h, k = self.center
        c = self.c()
        if self.transverse_axis == "x":
            return (h - c, k), (h + c, k)
        return (h, k - c), (h, k + c)

    def asymptotes(self) -> str:
        h, k = self.center
        if self.transverse_axis == "x":
            m = self.b / self.a
            return f"y - ({k}) = ±{m:.6g}(x - ({h}))"
        m = self.a / self.b
        return f"y - ({k}) = ±{m:.6g}(x - ({h}))"


@dataclass
class Parabola:
    p: float
    orientation: str

    def focus(self) -> tuple[float, float]:
        if self.orientation == "x":
            return (self.p / 2, 0.0)
        return (0.0, self.p / 2)

    def directrix(self) -> str:
        if self.orientation == "x":
            return f"x = {-self.p / 2:.6g}"
        return f"y = {-self.p / 2:.6g}"


def print_pair(name: str, value) -> None:
    print(f"{name}: {value}")


# ============================================================
# TASK 1. Эллиптическая зона покрытия
# ============================================================
print("TASK 1. Эллипс x^2/9 + y^2/4 = 1")
ellipse_1 = Ellipse(center=(0.0, 0.0), a=3.0, b=2.0, major_axis="x")
print_pair("тип", "эллипс")
print_pair("центр", ellipse_1.center)
print_pair("a, b", (ellipse_1.a, ellipse_1.b))
print_pair("c", ellipse_1.c())
print_pair("фокусы", ellipse_1.foci())

# TODO: перенесите полуоси и фокусы в рабочую тетрадь.


# ============================================================
# TASK 2. Смещённый эллипс
# ============================================================
print("\nTASK 2. Эллипс (x-1)^2/16 + (y+1)^2/4 = 1")
ellipse_2 = Ellipse(center=(1.0, -1.0), a=4.0, b=2.0, major_axis="x")
print_pair("центр", ellipse_2.center)
print_pair("a, b", (ellipse_2.a, ellipse_2.b))
print_pair("c", ellipse_2.c())
print_pair("фокусы", ellipse_2.foci())

# TODO: объясните, как смещение центра меняет координаты фокусов.


# ============================================================
# TASK 3. Гиперболическая модель навигации
# ============================================================
print("\nTASK 3. Гипербола x^2/16 - y^2/9 = 1")
hyperbola_1 = Hyperbola(center=(0.0, 0.0), a=4.0, b=3.0, transverse_axis="x")
print_pair("тип", "гипербола")
print_pair("a, b", (hyperbola_1.a, hyperbola_1.b))
print_pair("c", hyperbola_1.c())
print_pair("фокусы", hyperbola_1.foci())
print_pair("асимптоты", hyperbola_1.asymptotes())

# TODO: запишите асимптоты в виде y = kx и y = -kx.


# ============================================================
# TASK 4. Эллипс с вертикальной большой осью
# ============================================================
print("\nTASK 4. Эллипс x^2 + y^2/9 = 1")
ellipse_3 = Ellipse(center=(0.0, 0.0), a=3.0, b=1.0, major_axis="y")
print_pair("большая ось", "ось Oy")
print_pair("полуоси по x и y", (1.0, 3.0))
print_pair("c", ellipse_3.c())
print_pair("фокусы", ellipse_3.foci())

# TODO: укажите габариты зоны: ширина и высота.


# ============================================================
# TASK 5. Параболический отражатель
# ============================================================
print("\nTASK 5. Парабола y^2 = -4x")
parabola_1 = Parabola(p=-2.0, orientation="x")
print_pair("2p", -4.0)
print_pair("p", parabola_1.p)
print_pair("фокус", parabola_1.focus())
print_pair("директриса", parabola_1.directrix())
print_pair("направление раскрытия", "влево")

# TODO: сверьте знак параметра p с направлением раскрытия.


# ============================================================
# TASK 6. Приведение общего уравнения эллипса
# ============================================================
print("\nTASK 6. 5x^2 + 9y^2 - 30x + 18y + 9 = 0")
# 5(x-3)^2 + 9(y+1)^2 = 45
# (x-3)^2/9 + (y+1)^2/5 = 1
ellipse_4 = Ellipse(center=(3.0, -1.0), a=3.0, b=math.sqrt(5.0), major_axis="x")
print_pair("канонический вид", "(x-3)^2/9 + (y+1)^2/5 = 1")
print_pair("центр", ellipse_4.center)
print_pair("a, b", (ellipse_4.a, ellipse_4.b))
print_pair("c", ellipse_4.c())
print_pair("фокусы", ellipse_4.foci())

# TODO: покажите в рабочей тетради выделение квадратов.


# ============================================================
# TASK 7. Приведение общего уравнения гиперболы
# ============================================================
print("\nTASK 7. x^2 - y^2/3 - 2x - 2y + 1 = 0")
# (x-1)^2 - (y+3)^2/3 = 1
hyperbola_2 = Hyperbola(center=(1.0, -3.0), a=1.0, b=math.sqrt(3.0), transverse_axis="x")
print_pair("канонический вид", "(x-1)^2 - (y+3)^2/3 = 1")
print_pair("центр", hyperbola_2.center)
print_pair("a, b", (hyperbola_2.a, hyperbola_2.b))
print_pair("c", hyperbola_2.c())
print_pair("фокусы", hyperbola_2.foci())
print_pair("асимптоты", hyperbola_2.asymptotes())

# TODO: запишите асимптоты в ручном виде: y + 3 = ±sqrt(3)(x - 1).


# ============================================================
# TASK 8. Сводная диагностика
# ============================================================
print("\nTASK 8. Сводная диагностика")
objects = [
    ("x^2/9 + y^2/4 = 1", "эллипс", "центр, полуоси, фокусы"),
    ("(x-1)^2/16 + (y+1)^2/4 = 1", "эллипс", "центр, полуоси, фокусы"),
    ("x^2/16 - y^2/9 = 1", "гипербола", "центр, полуоси, фокусы, асимптоты"),
    ("y^2 = -4x", "парабола", "параметр p, фокус, директриса"),
    ("5x^2 + 9y^2 - 30x + 18y + 9 = 0", "эллипс", "канонический вид после выделения квадратов"),
    ("x^2 - y^2/3 - 2x - 2y + 1 = 0", "гипербола", "канонический вид, асимптоты"),
]
for equation, kind, params in objects:
    print(f"{equation:45s} -> {kind:10s}; хранить: {params}")

print("\nИтог: для визуализации кривых модулю нужны тип кривой, центр, ориентация, параметры a/b или p, а также фокусы и асимптоты/директриса при необходимости.")

# TODO: сформулируйте инженерное заключение в рабочей тетради.
