"""
Дополнительная программа к кейсу 10 «3D-навигация дрона в пространстве».
Тема: прямая и плоскость в пространстве.

Что делает студент:
1. Запускает файл после установки NumPy.
2. Выполняет блоки TASK 1--TASK 8.
3. Сравнивает результаты с рабочей тетрадью.
4. Сдаёт заполненный .py файл вместе с PDF рабочей тетради.
"""

import numpy as np

np.set_printoptions(precision=4, suppress=True)
EPS = 1e-9


def cross(a, b):
    return np.cross(np.array(a, dtype=float), np.array(b, dtype=float))


def dot(a, b):
    return float(np.dot(np.array(a, dtype=float), np.array(b, dtype=float)))


def norm(a):
    return float(np.linalg.norm(np.array(a, dtype=float)))


def plane_from_point_normal(point, normal):
    """Возвращает коэффициенты A,B,C,D плоскости Ax+By+Cz+D=0."""
    p = np.array(point, dtype=float)
    n = np.array(normal, dtype=float)
    D = -dot(n, p)
    return np.array([n[0], n[1], n[2], D], dtype=float)


def plane_from_three_points(A, B, C):
    A, B, C = map(lambda x: np.array(x, dtype=float), (A, B, C))
    normal = cross(B - A, C - A)
    return plane_from_point_normal(A, normal)


def line_from_two_points(A, B):
    A, B = map(lambda x: np.array(x, dtype=float), (A, B))
    return A, B - A


def line_plane_intersection(P, q, plane):
    """P+tq и Ax+By+Cz+D=0."""
    P = np.array(P, dtype=float)
    q = np.array(q, dtype=float)
    n = np.array(plane[:3], dtype=float)
    D = float(plane[3])
    denom = dot(n, q)
    if abs(denom) < EPS:
        return None
    t = -(dot(n, P) + D) / denom
    return P + t * q, t


def point_to_plane_projection(P, plane):
    P = np.array(P, dtype=float)
    n = np.array(plane[:3], dtype=float)
    D = float(plane[3])
    k = (dot(n, P) + D) / dot(n, n)
    return P - k * n


def point_to_line_distance(M, P, q):
    M, P, q = map(lambda x: np.array(x, dtype=float), (M, P, q))
    return norm(cross(M - P, q)) / norm(q)


def print_plane(name, plane):
    A, B, C, D = plane
    print(f"{name}: {A:.4g}x + {B:.4g}y + {C:.4g}z + {D:.4g} = 0")


def print_line(name, P, q):
    print(f"{name}: P={P}, q={q}")
    print(f"  param: x={P[0]:.4g}+({q[0]:.4g})t, y={P[1]:.4g}+({q[1]:.4g})t, z={P[2]:.4g}+({q[2]:.4g})t")


# ============================================================
# TASK 1. Плоскость по трём точкам
# ============================================================
print("TASK 1. Плоскость по трём точкам")
A = np.array([3, -1, 2], dtype=float)
B = np.array([4, -1, -1], dtype=float)
C = np.array([2, 0, 2], dtype=float)
plane_ABC = plane_from_three_points(A, B, C)
print("AB =", B - A)
print("AC =", C - A)
print("normal = AB x AC =", cross(B - A, C - A))
print_plane("plane ABC", plane_ABC)

# TODO: перенесите в рабочую тетрадь векторы AB, AC и нормаль.

# ============================================================
# TASK 2. Плоскость через точку параллельно двум векторам
# ============================================================
print("\nTASK 2. Плоскость через точку параллельно векторам")
M = np.array([2, -3, -1], dtype=float)
a = np.array([2, -4, -1], dtype=float)
b = np.array([1, 2, 3], dtype=float)
normal2 = cross(a, b)
plane2 = plane_from_point_normal(M, normal2)
print("a x b =", normal2)
print_plane("plane through M parallel a,b", plane2)

# TODO: объясните, почему нормаль равна векторному произведению.

# ============================================================
# TASK 3. Угол и расстояние между плоскостями
# ============================================================
print("\nTASK 3. Угол и расстояние между плоскостями")
pi1 = np.array([1, -7, 2, 0], dtype=float)
pi2 = np.array([5, 3, -2, 0], dtype=float)
n1, n2 = pi1[:3], pi2[:3]
cos_angle = abs(dot(n1, n2)) / (norm(n1) * norm(n2))
angle_deg = np.degrees(np.arccos(np.clip(cos_angle, -1, 1)))
print(f"angle between planes = {angle_deg:.4f} degrees")

pA = np.array([1, -1, 2, 1], dtype=float)
pB = np.array([2, -2, 4, 3], dtype=float)
# Нормируем вторую плоскость: делим на 2, получаем x-y+2z+1.5=0.
distance_parallel = abs(1.5 - 1.0) / norm([1, -1, 2])
print(f"distance between x-y+2z+1=0 and 2x-2y+4z+3=0 = {distance_parallel:.6f}")

# TODO: в тетради запишите нормали и используемые формулы.

# ============================================================
# TASK 4. Прямая по двум точкам
# ============================================================
print("\nTASK 4. Прямая по двум точкам")
P0, q = line_from_two_points([4, -1, 1], [3, 3, -1])
print_line("AB", P0, q)

# TODO: запишите каноническое и параметрическое уравнения.

# ============================================================
# TASK 5. Прямая как пересечение двух плоскостей
# ============================================================
print("\nTASK 5. Прямая как пересечение двух плоскостей")
pl1 = np.array([1, -2, 3, 1], dtype=float)
pl2 = np.array([2, 1, -4, -8], dtype=float)
q5 = cross(pl1[:3], pl2[:3])
# Ищем одну точку: положим z=0 и решим систему по x,y.
sol_xy = np.linalg.solve(np.array([[1, -2], [2, 1]], dtype=float), np.array([-1, 8], dtype=float))
P5 = np.array([sol_xy[0], sol_xy[1], 0.0])
print("direction = n1 x n2 =", q5)
print_line("intersection line", P5, q5)

# TODO: проверьте, что точка P5 удовлетворяет обеим плоскостям.

# ============================================================
# TASK 6. Пересечение прямой и плоскости. Угол прямой и плоскости
# ============================================================
print("\nTASK 6. Прямая и плоскость")
L_P = np.array([1, 0, 1], dtype=float)
L_q = np.array([4, 12, -3], dtype=float)
plane6 = np.array([6, -3, 2, 0], dtype=float)
intersection, t = line_plane_intersection(L_P, L_q, plane6)
print("intersection with 6x-3y+2z=0:", intersection, "t=", t)
plane6b = np.array([6, -3, 2, 1], dtype=float)
sin_alpha = abs(dot(plane6b[:3], L_q)) / (norm(plane6b[:3]) * norm(L_q))
alpha_deg = np.degrees(np.arcsin(np.clip(sin_alpha, -1, 1)))
print(f"angle between line and plane 6x-3y+2z+1=0 = {alpha_deg:.4f} degrees")

# TODO: сравните знак параметра t с положением точки пересечения на траектории.

# ============================================================
# TASK 7. Проекция точки на плоскость и расстояние от точки до прямой
# ============================================================
print("\nTASK 7. Проекция и расстояние")
A7 = np.array([5, 2, -1], dtype=float)
plane7 = np.array([2, -1, 3, 23], dtype=float)
proj7 = point_to_plane_projection(A7, plane7)
dist_plane7 = abs(dot(plane7[:3], A7) + plane7[3]) / norm(plane7[:3])
print("projection of A on plane =", proj7)
print(f"distance from A to plane = {dist_plane7:.6f}")
M7 = np.array([3, 1, 2], dtype=float)
Pline7 = np.array([1, 0, -1], dtype=float)
qline7 = np.array([2, 1, 0], dtype=float)
dist_line7 = point_to_line_distance(M7, Pline7, qline7)
print(f"distance from M to line = {dist_line7:.6f}")

# TODO: в тетради запишите геометрический смысл проекции.

# ============================================================
# TASK 8. Скрещивающиеся прямые и инженерное заключение
# ============================================================
print("\nTASK 8. Скрещивающиеся прямые")
P1 = np.array([-7, -4, -3], dtype=float)
q1 = np.array([3, 4, -2], dtype=float)
P2 = np.array([21, -5, 2], dtype=float)
q2 = np.array([6, -4, -1], dtype=float)
triple = dot(P2 - P1, cross(q1, q2))
print("mixed product =", triple)
print("skew?", "yes" if abs(triple) > EPS and norm(cross(q1, q2)) > EPS else "no")
skew_distance = abs(triple) / norm(cross(q1, q2))
print(f"distance between skew lines = {skew_distance:.6f}")
plane_parallel = plane_from_point_normal(P1, cross(q1, q2))
print_plane("plane through L1 parallel L2", plane_parallel)

# TODO: сформулируйте заключение: какие проверки нужны для 3D-навигации.
