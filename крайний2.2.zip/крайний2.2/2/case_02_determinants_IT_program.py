"""
Дополнительная программа к кейсу 2 «Определители в диагностике устойчивости IT-системы».
Тема: определители, миноры, алгебраические дополнения, вырожденность матриц.

Что делает студент:
1. Запускает файл после установки NumPy.
2. Выполняет блоки TASK 1--TASK 8.
3. Сравнивает результаты с рабочей тетрадью.
4. Сдаёт заполненный .py файл вместе с PDF рабочей тетради.
"""

import numpy as np

np.set_printoptions(precision=4, suppress=True)

D = np.array([
    [3, 1, 0, 2],
    [1, 4, 1, 0],
    [0, 2, 5, 1],
    [2, 0, 1, 3],
], dtype=float)

Q = np.array([
    [2, -1, 3],
    [0, 4, 1],
    [1, 2, -2],
], dtype=float)

R = np.array([
    [4, 2, 6],
    [2, 1, 3],
    [0, 5, 1],
], dtype=float)


def det_value(matrix: np.ndarray) -> float:
    """Возвращает определитель, округлённый для удобного вывода."""
    return float(np.linalg.det(matrix))


def print_matrix(name: str, matrix: np.ndarray) -> None:
    print(f"\n{name} shape={matrix.shape}")
    print(matrix)


def minor(matrix: np.ndarray, row: int, col: int) -> np.ndarray:
    """Минор: удаление строки row и столбца col. Индексы Python начинаются с 0."""
    return np.delete(np.delete(matrix, row, axis=0), col, axis=1)


def cofactor(matrix: np.ndarray, row: int, col: int) -> float:
    """Алгебраическое дополнение элемента matrix[row, col]."""
    sign = (-1) ** (row + col)
    return sign * det_value(minor(matrix, row, col))


def D_alpha(alpha: float) -> np.ndarray:
    """Параметрическая диагностическая матрица D(alpha)."""
    matrix = D.copy()
    matrix[0, 3] = alpha
    return matrix


# ============================================================
# TASK 1. Исходные матрицы и размерности
# ============================================================
print("TASK 1. Исходные матрицы")
print_matrix("D", D)
print_matrix("Q", Q)
print_matrix("R", R)
print("D shape:", D.shape)
print("Q shape:", Q.shape)
print("R shape:", R.shape)

# TODO: в рабочей тетради запишите, у каких матриц можно считать определитель и почему.


# ============================================================
# TASK 2. Определитель D и обратимость модели
# ============================================================
print("\nTASK 2. Определитель D")
det_D = det_value(D)
rank_D = np.linalg.matrix_rank(D)
print(f"det(D) = {det_D:.6f}")
print(f"rank(D) = {rank_D}")
print("Модель обратима?", "да" if abs(det_D) > 1e-9 else "нет")

# TODO: сравните этот результат с ручным приведением к треугольному виду.


# ============================================================
# TASK 3. Разложение det(Q) по второй строке
# ============================================================
print("\nTASK 3. Разложение det(Q) по второй строке")
det_Q = det_value(Q)
print(f"det(Q) через NumPy = {det_Q:.6f}")

laplace_sum = 0.0
row = 1  # вторая строка в математической нумерации
for col in range(Q.shape[1]):
    m = minor(Q, row, col)
    cof = cofactor(Q, row, col)
    term = Q[row, col] * cof
    laplace_sum += term
    print(f"j={col + 1}: q_2{col + 1}={Q[row, col]:.0f}, minor=\n{m}, cofactor={cof:.0f}, term={term:.0f}")
print(f"Сумма разложения по второй строке = {laplace_sum:.6f}")

# TODO: перенесите миноры и алгебраические дополнения в рабочую тетрадь.


# ============================================================
# TASK 4. Вырожденность R
# ============================================================
print("\nTASK 4. Вырожденная матрица R")
det_R = det_value(R)
rank_R = np.linalg.matrix_rank(R)
print(f"det(R) = {det_R:.6f}")
print(f"rank(R) = {rank_R}")
print("Проверка пропорциональности: первая строка R равна 2 * второй строке?", np.allclose(R[0], 2 * R[1]))

# TODO: сформулируйте прикладной смысл: зависимые строки означают зависимые метрики.


# ============================================================
# TASK 5. Параметр alpha
# ============================================================
print("\nTASK 5. Параметрическая матрица D(alpha)")
alpha_values = [0, 1, 2, 3, 4, 5]
alpha_results = []
for alpha in alpha_values:
    value = det_value(D_alpha(alpha))
    alpha_results.append((alpha, value))
    print(f"alpha={alpha}: det(D_alpha)={value:.6f}")

closest_alpha, closest_det = min(alpha_results, key=lambda pair: abs(pair[1]))
print(f"Ближе всего к нулю: alpha={closest_alpha}, det={closest_det:.6f}")

# TODO: перенесите таблицу значений в рабочую тетрадь.


# ============================================================
# TASK 6. Сравнение методов вычисления
# ============================================================
print("\nTASK 6. Сравнение методов")
print("Для Q удобно разложение по второй строке, потому что в ней есть ноль.")
print("Для D удобнее приведение к треугольному виду, потому что порядок 4.")
print("Для R полный расчёт не нужен: достаточно заметить пропорциональные строки.")

# TODO: заполните таблицу сравнения методов в рабочей тетради.


# ============================================================
# TASK 7. Дополнительная диагностика: число обусловленности
# ============================================================
print("\nTASK 7. Число обусловленности")
cond_D = np.linalg.cond(D)
print(f"cond(D) = {cond_D:.6f}")
for alpha in alpha_values:
    matrix = D_alpha(alpha)
    det_a = det_value(matrix)
    cond_a = np.linalg.cond(matrix)
    print(f"alpha={alpha}: det={det_a:.6f}, cond={cond_a:.6f}")

# TODO: чем больше число обусловленности, тем осторожнее нужно интерпретировать численное решение.


# ============================================================
# TASK 8. Итоговые факты для инженерного заключения
# ============================================================
print("\nTASK 8. Итоговые факты")
print(f"1. det(D) = {det_D:.0f}, поэтому основная диагностическая модель обратима.")
print(f"2. det(Q) = {det_Q:.0f}; результат можно получить разложением по второй строке.")
print(f"3. det(R) = {det_R:.0f}, потому что первая строка равна 2 * второй строке.")
print(f"4. Среди alpha=0..5 ближе всего к нулю det при alpha={closest_alpha}.")
print("5. Итоговую рекомендацию сформулируйте в рабочей тетради.")
