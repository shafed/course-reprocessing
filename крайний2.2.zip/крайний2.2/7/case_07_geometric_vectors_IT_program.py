"""
Дополнительная программа к кейсу 7 «Векторная диагностика маршрута автономного сервисного робота».
Тема: геометрические векторы, длина, скалярное произведение, угол, проекция, деление отрезка.

Что делает студент:
1. Запускает файл после установки NumPy.
2. Выполняет блоки TASK 1--TASK 8.
3. Сравнивает результаты с рабочей тетрадью.
4. Сдаёт заполненный .py файл вместе с PDF рабочей тетради.
"""

import numpy as np

np.set_printoptions(precision=4, suppress=True)

A = np.array([1, 1, 4], dtype=float)
B = np.array([2, 3, -1], dtype=float)
C = np.array([-2, 2, 0], dtype=float)

P = np.array([1, 2, 3], dtype=float)
Q = np.array([7, 3, 2], dtype=float)
R = np.array([-3, 0, 6], dtype=float)
S = np.array([9, 2, 4], dtype=float)

a = np.array([-1, 2, 1], dtype=float)
b = np.array([3, 1, 1], dtype=float)
c = np.array([4, 3, 0], dtype=float)


def vec(start: np.ndarray, finish: np.ndarray) -> np.ndarray:
    """Возвращает координаты вектора от start к finish."""
    return finish - start


def length(v: np.ndarray) -> float:
    """Длина вектора."""
    return float(np.linalg.norm(v))


def dot(u: np.ndarray, v: np.ndarray) -> float:
    """Скалярное произведение."""
    return float(np.dot(u, v))


def angle_deg(u: np.ndarray, v: np.ndarray) -> float:
    """Угол между ненулевыми векторами в градусах."""
    cosine = dot(u, v) / (length(u) * length(v))
    cosine = np.clip(cosine, -1.0, 1.0)
    return float(np.degrees(np.arccos(cosine)))


def are_collinear(u: np.ndarray, v: np.ndarray) -> bool:
    """Проверка коллинеарности через векторное произведение."""
    return np.allclose(np.cross(u, v), np.zeros(3))


# ============================================================
# TASK 1. Векторы перемещения
# ============================================================
print("TASK 1. Векторы перемещения")
AB = vec(A, B)
AC = vec(A, C)
print("A =", A, "B =", B, "C =", C)
print("AB =", AB)
print("AC =", AC)
print("AB + AC =", AB + AC)
print("AB - AC =", AB - AC)
print(f"|AB| = {length(AB):.6f}")
print(f"|AC| = {length(AC):.6f}")

# TODO: перенесите координаты векторов и длины в рабочую тетрадь.


# ============================================================
# TASK 2. Четвёртая вершина параллелограмма
# ============================================================
print("\nTASK 2. Четвёртая вершина параллелограмма")
D = A + C - B
print("D = A + C - B =", D)
print("AD =", vec(A, D))
print("BC =", vec(B, C))
print("AB =", vec(A, B))
print("DC =", vec(D, C))
print("AD и BC равны?", np.allclose(vec(A, D), vec(B, C)))
print("AB и DC равны?", np.allclose(vec(A, B), vec(D, C)))

# TODO: объясните, почему эта формула даёт четвёртую вершину.


# ============================================================
# TASK 3. Перпендикулярность диагоналей
# ============================================================
print("\nTASK 3. Диагонали контрольного четырёхугольника")
PR = vec(P, R)
QS = vec(Q, S)
print("PR =", PR)
print("QS =", QS)
print("(PR, QS) =", dot(PR, QS))
print("Диагонали перпендикулярны?", "да" if abs(dot(PR, QS)) < 1e-9 else "нет")

# TODO: в рабочей тетради запишите скалярное произведение и вывод.


# ============================================================
# TASK 4. Длины сторон и углы треугольника
# ============================================================
print("\nTASK 4. Длины сторон и углы треугольника")
T_A = np.array([-1, -2, 4], dtype=float)
T_B = np.array([-4, -2, 0], dtype=float)
T_C = np.array([3, -2, 1], dtype=float)

side_AB = length(vec(T_A, T_B))
side_BC = length(vec(T_B, T_C))
side_CA = length(vec(T_C, T_A))
angle_A = angle_deg(vec(T_A, T_B), vec(T_A, T_C))
angle_B = angle_deg(vec(T_B, T_A), vec(T_B, T_C))
angle_C = angle_deg(vec(T_C, T_A), vec(T_C, T_B))
print(f"AB = {side_AB:.6f}")
print(f"BC = {side_BC:.6f}")
print(f"CA = {side_CA:.6f}")
print(f"angle A = {angle_A:.6f} degrees")
print(f"angle B = {angle_B:.6f} degrees")
print(f"angle C = {angle_C:.6f} degrees")
print(f"sum angles = {angle_A + angle_B + angle_C:.6f} degrees")

# TODO: оцените, какой угол означает самый резкий поворот маршрута.


# ============================================================
# TASK 5. Проверка трапеции
# ============================================================
print("\nTASK 5. Проверка трапеции")
K = np.array([3, -1, 2], dtype=float)
L = np.array([1, 2, -1], dtype=float)
M = np.array([-1, 1, -3], dtype=float)
N = np.array([3, -5, 3], dtype=float)
KL = vec(K, L)
LM = vec(L, M)
MN = vec(M, N)
NK = vec(N, K)
print("KL =", KL)
print("LM =", LM)
print("MN =", MN)
print("NK =", NK)
print("KL и MN коллинеарны?", are_collinear(KL, MN))
print("LM и NK коллинеарны?", are_collinear(LM, NK))
if are_collinear(KL, MN):
    print(f"Длины параллельных сторон: |KL|={length(KL):.6f}, |MN|={length(MN):.6f}")
if are_collinear(LM, NK):
    print(f"Длины параллельных сторон: |LM|={length(LM):.6f}, |NK|={length(NK):.6f}")

# TODO: сформулируйте, какая пара сторон является основаниями трапеции.


# ============================================================
# TASK 6. Проекция управляющего сигнала
# ============================================================
print("\nTASK 6. Проекция управляющего сигнала")
signal = 2 * a - 3 * b
projection = dot(signal, c) / length(c)
print("a =", a)
print("b =", b)
print("c =", c)
print("2a - 3b =", signal)
print(f"projection on c = {projection:.6f}")
print("Знак проекции:", "сонаправлена с c" if projection > 0 else "противоположна направлению c" if projection < 0 else "ортогональна c")

# TODO: объясните прикладной смысл отрицательной, положительной или нулевой проекции.


# ============================================================
# TASK 7. Деление отрезка на три равные части
# ============================================================
print("\nTASK 7. Деление отрезка на три равные части")
U = np.array([3, -2], dtype=float)
V = np.array([6, 4], dtype=float)
T1 = U + (V - U) / 3
T2 = U + 2 * (V - U) / 3
print("U =", U)
print("V =", V)
print("T1 =", T1)
print("T2 =", T2)
print(f"|UT1| = {length(T1 - U):.6f}")
print(f"|T1T2| = {length(T2 - T1):.6f}")
print(f"|T2V| = {length(V - T2):.6f}")

# TODO: перенесите координаты точек деления в рабочую тетрадь.


# ============================================================
# TASK 8. Итоговые факты для инженерного заключения
# ============================================================
print("\nTASK 8. Итоговые факты")
print(f"1. Перемещение AB имеет длину {length(AB):.3f}, AC имеет длину {length(AC):.3f}.")
print(f"2. Четвёртая вершина параллелограмма: D = {D}.")
print(f"3. Диагонали PR и QS перпендикулярны: {abs(dot(PR, QS)) < 1e-9}.")
print(f"4. Проекция управляющего сигнала на направление c равна {projection:.3f}.")
print("5. Итоговую рекомендацию сформулируйте в рабочей тетради.")
